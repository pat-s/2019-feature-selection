library("testthat")
library("workflowr")

test_check("workflowr")
