carHexsticker <- function(){
  browseURL(paste0("file://", system.file("doc", "car-hex.pdf", package="car")))
}