context("Install uninstalled formats")

test_that("install_formats()", {
    expect_true(install_formats())
})
