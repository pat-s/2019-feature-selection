library("testthat")
library("prediction")
test_check("prediction")
