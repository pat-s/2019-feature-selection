#' @rdname prediction
#' @export
prediction.ksvm <- prediction.gausspr
