#' @rdname prediction
#' @export
prediction.mclogit <- prediction.glm
