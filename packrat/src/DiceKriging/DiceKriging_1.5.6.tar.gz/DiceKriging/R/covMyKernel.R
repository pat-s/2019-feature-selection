# definir la classe

# ensuite methode covMatrix

# pour prediction, rajouter covMat1Mat2

# pour estimation, rajouter
# - covparam2vect, vect2covparam
# - covparametersBounds
# - covMatrixDerivative

# pour EGO rajouter 
# - covMatrix.dx, covDerivative.dx

# pour l'affichage, rajouter :
# - show
# - coefficients (alias coef)

# Pour la portabilite, penser a : 
# - inputNames, nInput, nuggetValue, kernelNames, etc.
