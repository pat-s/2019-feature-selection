# addinslist 0.2 2016-09-28

- remove deprecated xml2 function
