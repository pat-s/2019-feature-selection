library(testthat)
library(cranlike)

test_check("cranlike")
