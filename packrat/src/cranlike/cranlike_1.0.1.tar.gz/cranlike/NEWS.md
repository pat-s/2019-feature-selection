
# 1.0.1

* `package_versions()` can list extra columns from the database now

# 1.0.0

First public release.
