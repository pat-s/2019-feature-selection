
analyze_licenses <- function(x) {
  ("tools" %:::% "analyze_licenses")(x)
}
