
.onLoad <- function(libname, pkgname) {
  debugme::debugme()                    # nocov
}
