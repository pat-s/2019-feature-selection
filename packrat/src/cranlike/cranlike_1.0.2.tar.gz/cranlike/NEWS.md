
# 1.0.2

* `create_empty_PACKAGES()`, `add_PACKAGES()`, `update_PACKAGES()` and
  `remove_PACKAGES()` lock the DB, to avoid potential concurrency issues.

# 1.0.1

* `package_versions()` can list extra columns from the database now

# 1.0.0

First public release.
