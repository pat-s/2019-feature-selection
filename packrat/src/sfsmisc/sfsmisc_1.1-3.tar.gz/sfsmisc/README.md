sfsmisc
=======

The R package sfsmisc  has finally made it into a revision control system,
and the fad of the day being git & github, so be it!

sfsmisc has been on CRAN for a very long time, and containing R code that is up to 17.5 years old. ([See](https://mmaechler.blogspot.com/2014/08/how-i-got-175-years-old-github.html)
on how I got this into github, including parts of the long history.)

It is a collection of "goodies" as we used to call these nice utility functions.  Whereas the package has been 
written and maintained by Martin Maechler, really there are quite a few more members of the SfS (Seminar fuer Statistik at ETH Zurich)
who have authored some of the functions or contributed to them.

DESCRIPTION
===========
Useful utilities 'goodies' from Seminar fuer Statistik ETH Zurich, quite a few related to graphics; many ported from S-plus times.
