CVST
====

Fast Cross-Validation via Sequential Testing

The package CVST is hosted on CRAN, so

    install.packages("CVST")
    library(CVST)
    example(CVST)

will give you a first impression.