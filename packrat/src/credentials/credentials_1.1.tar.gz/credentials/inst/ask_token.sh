#!/bin/sh
exec $GIT_ASKTOKEN "Please enter your TOKEN"
