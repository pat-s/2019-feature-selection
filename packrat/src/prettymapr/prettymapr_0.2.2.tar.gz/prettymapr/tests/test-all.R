
library(testthat)

test_check("prettymapr")
