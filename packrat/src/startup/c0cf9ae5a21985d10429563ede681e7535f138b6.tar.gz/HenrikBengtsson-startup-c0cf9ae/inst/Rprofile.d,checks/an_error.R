## If an error occurs during startup::startup(), they
## may optionally be converted to warnings, messages
## or simply be ignored.  See help("startup")
stop("An error occurred")
