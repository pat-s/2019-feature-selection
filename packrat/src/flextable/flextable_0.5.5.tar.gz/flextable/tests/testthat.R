library(testthat)
library(flextable)

test_check("flextable")
