# addmins

An R package containing addins that are useful for Mine's workflow.
