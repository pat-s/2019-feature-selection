
#include <R.h>
#include <Rinternals.h>
#include <Rdefines.h>

SEXP R_rfweights (SEXP fdata, SEXP fnewdata, SEXP weights, SEXP scale);

