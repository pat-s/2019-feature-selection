library(testthat)
library(infuser)

test_check("infuser")
