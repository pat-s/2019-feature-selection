library(testthat)
test_check("narray")
