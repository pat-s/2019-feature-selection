
/*Global declarations*/
extern int DIM;
extern int trialid;
extern double * peaks;
extern double * Xopt; /*Initialized in benchmarkhelper.c*/
extern double Fopt;
extern unsigned int isInitDone;
