extern SEXP encoding(SEXP chars);
extern SEXP all_utf8(SEXP chars);
