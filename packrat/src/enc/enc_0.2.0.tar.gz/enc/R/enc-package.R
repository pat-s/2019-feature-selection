#' @useDynLib enc, .registration = TRUE, .fixes = "C_"
#' @aliases NULL
"_PACKAGE"
