df = data.frame(a=rnorm(10), b=rnorm(10))

fit = lm(b~a, data=df)
