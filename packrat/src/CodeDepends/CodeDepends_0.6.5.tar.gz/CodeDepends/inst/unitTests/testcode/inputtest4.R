x = pi*3

f = function(x)
    {
        x + 6
    }

res = sapply(1:5, f)

res2 = sapply(1:5, rnorm)

y = f(5)
