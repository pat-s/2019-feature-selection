{
  assign("assigned", 5)
  dblarrow <<- 7
}
