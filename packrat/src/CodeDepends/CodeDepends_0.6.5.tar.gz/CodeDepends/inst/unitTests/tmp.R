library(CodeDepends)
scr = readScript("testcode/inputtest1.R")
