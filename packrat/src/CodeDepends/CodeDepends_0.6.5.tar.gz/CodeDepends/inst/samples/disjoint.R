a = 1
b = 2
c = 3

x = a + b + c

o = f(x)

o = g(x)

foo(o)

y = 1

z = y + 1

