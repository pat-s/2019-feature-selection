{
  electionResults = read.table("myData")
}

{
  population = read.table("pop")
}

{
  census = read.table('ethnicity')
}


{
  f = foo()
  plot(electionResults, census, population)
}

{
  y = bar(f)
}

{
  p = plot(y)
}

{
 op1(z)
}

