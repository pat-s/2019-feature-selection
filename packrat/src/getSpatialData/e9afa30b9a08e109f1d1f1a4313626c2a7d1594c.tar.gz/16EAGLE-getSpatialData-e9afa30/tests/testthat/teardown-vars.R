unlink(vars.global$dir.arc)
file.remove("Rplots.pdf")
