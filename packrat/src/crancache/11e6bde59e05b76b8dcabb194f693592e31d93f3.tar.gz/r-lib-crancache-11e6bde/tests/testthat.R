library(testthat)
library(crancache)

test_check("crancache")
