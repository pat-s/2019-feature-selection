
context("crancache")

test_that("crancache works", {

  expect_true(TRUE)

})
