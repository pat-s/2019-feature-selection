library(testthat)
library(ggspatial)

test_check("ggspatial")
