## Test environments
* Ubuntu 14.04, R 3.4.1
* macOS 10.12.6, R 3.3.2
* Windows Server 2008 R2 SP1, R-release

## R CMD check results
There were no ERRORs, WARNINGs or NOTEs.

## Downstream dependencies
There are currently no downstream dependencies for this package.