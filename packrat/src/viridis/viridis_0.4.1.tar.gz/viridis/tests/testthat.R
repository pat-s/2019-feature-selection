library(testthat)
library(viridis)
library(ggplot2)
library(MASS)
library(gridExtra)

test_check("viridis")
