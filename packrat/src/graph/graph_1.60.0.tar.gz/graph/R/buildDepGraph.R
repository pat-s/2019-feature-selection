pkgInstOrder <- function() {
    .Defunct("getInstallOrder", package="pkgDepTools")
}

buildRepDepGraph <- function() {
    .Defunct("makeDepGraph", package="pkgDepTools")
}

