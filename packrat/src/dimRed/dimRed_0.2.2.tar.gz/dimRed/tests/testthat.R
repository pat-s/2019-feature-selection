library(testthat)
library(dimRed)

test_check("dimRed", reporter = ListReporter)
