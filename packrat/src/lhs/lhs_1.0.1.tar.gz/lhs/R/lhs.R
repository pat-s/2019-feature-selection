# Copyright 2019 Robert Carnell

#' @useDynLib lhs
#' @keywords internal
#' @import Rcpp
"_PACKAGE"
