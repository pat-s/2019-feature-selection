library(testthat)
library(janitor)

test_check("janitor")
