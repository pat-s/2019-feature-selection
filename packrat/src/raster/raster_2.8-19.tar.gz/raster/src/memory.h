double availableRAM();
