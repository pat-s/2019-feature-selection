#' @param learner ([Learner] | `character(1)`)\cr
#'   The classification learner.
#'   If you pass a string the learner will be created via [makeLearner].
#' @md
