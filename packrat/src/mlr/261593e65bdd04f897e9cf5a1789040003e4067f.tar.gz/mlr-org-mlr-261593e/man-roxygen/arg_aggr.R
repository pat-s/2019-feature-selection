#' @param aggr ([Aggregation])\cr
#'   Aggregation function.
#' @md
