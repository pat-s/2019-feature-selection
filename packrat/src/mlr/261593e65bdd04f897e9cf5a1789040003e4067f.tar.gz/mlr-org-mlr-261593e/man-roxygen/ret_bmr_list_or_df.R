#' @return ([list] | [data.frame]). See above.
#' @md
