#' @param as.df (`character(1)`)\cr
#'   Return one [data.frame] as result - or a list of lists of objects?.
#'   Default is `FALSE`.
#' @md
