---
name: Miscellaneous
about: Suggest an idea or raise a concern.
title: ''
labels: ''
assignees: ''

---

## Prework

- [ ] Search for duplicates among the [existing issues](https://github.com/mlr-org/mlr/issues), both open and closed.

## Description

Describe the issue clearly and concisely. If applicable, write a minimal example in R code or pseudo-code to show input, usage, and desired output.
