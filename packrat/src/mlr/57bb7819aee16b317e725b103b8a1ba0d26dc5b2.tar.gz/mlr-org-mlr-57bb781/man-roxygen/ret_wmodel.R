#' @return [WrappedModel].
#' @md
