#' @param pred ([Prediction])\cr
#'   Prediction object.
#' @md
