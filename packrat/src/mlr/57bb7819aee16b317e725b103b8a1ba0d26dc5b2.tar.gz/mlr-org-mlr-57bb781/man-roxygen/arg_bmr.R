#' @param bmr ([BenchmarkResult])\cr
#'   Benchmark result.
#' @md
