#' @param subset ([integer] | [logical] | `NULL`)\cr
#'   Selected cases. Either a logical or an index vector.
#'   By default `NULL` if all observations are used.
#' @md
