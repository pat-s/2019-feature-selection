#' @param order.lrns (`character(n.learners)`)\cr
#'   Character vector with `learner.ids` in new order.
#' @md
