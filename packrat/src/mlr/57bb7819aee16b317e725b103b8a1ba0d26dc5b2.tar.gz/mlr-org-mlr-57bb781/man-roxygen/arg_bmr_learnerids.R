#' @param learner.ids (`character(1)`)\cr
#'   Restrict result to certain learners.
#'   Default is all.
#' @md

