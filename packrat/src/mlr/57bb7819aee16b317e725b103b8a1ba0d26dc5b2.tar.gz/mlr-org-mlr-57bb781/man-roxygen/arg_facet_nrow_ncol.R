#' @param facet.wrap.nrow,facet.wrap.ncol ([integer])\cr
#'   Number of rows and columns for facetting. Default for both is `NULL`.
#'   In this case ggplot's `facet_wrap` will choose the layout itself.
#' @md
