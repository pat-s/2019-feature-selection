#' @return ggplot2 plot object.
#' @md
