#' @param x ([Task] | [TaskDesc])\cr
#'   Task or its description object.
#' @md
