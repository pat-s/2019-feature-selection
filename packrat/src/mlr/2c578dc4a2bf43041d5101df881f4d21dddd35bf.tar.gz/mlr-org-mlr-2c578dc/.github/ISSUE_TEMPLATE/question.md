---
name: Question
about: Ask a question.
title: ''
labels: 'type-question'

---

## Prework

- [ ] Search for duplicates among the [existing issues](https://github.com/mlr-org/mlr/issues), both open and closed.
- [ ] Consider instead posting to [Stack Overflow](https://stackoverflow.com) under the [`mlr` tag](https://stackoverflow.com/tags/mlr).

## Question

What would you like to know?
