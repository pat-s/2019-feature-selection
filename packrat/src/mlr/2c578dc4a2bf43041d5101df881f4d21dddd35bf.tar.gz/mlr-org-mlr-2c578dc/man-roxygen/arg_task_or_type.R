#' @param obj (`character(1)` | [Task])\cr
#'   Either `character(1)` task or the type of the task, in the latter case one of:
#'   \dQuote{classif} \dQuote{regr} \dQuote{surv} \dQuote{costsens} \dQuote{cluster} \dQuote{multilabel}.
#'   Default is `NA` matching all types.
