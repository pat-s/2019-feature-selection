#' @param pretty.names (`logical(1)`)\cr
#'    Whether to use the short name of the learner instead of its ID in labels. Defaults to `TRUE`.
#' @md
