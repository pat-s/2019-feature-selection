#' @param measure ([Measure])\cr
#'   Performance measure.
#'   Default is the first measure used in the benchmark experiment.
#' @md
