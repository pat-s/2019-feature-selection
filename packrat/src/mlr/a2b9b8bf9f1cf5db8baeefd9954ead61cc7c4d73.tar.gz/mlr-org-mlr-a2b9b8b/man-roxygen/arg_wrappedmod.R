#' @param model ([WrappedModel])\cr
#'  The model.
#' @md
