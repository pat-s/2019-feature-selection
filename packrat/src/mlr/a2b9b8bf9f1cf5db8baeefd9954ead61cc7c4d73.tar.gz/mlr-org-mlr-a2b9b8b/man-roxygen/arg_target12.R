#' @param target (`character(1)` | `character(2)`)]\cr
#'   Name of the target variable(s).
#'   For survival analysis these are the names of the survival time and event columns,
#'   so it has length 2.
#' @md
