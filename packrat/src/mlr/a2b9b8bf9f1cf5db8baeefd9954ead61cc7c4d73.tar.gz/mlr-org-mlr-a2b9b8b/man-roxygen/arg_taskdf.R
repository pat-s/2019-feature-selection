#' @param obj ([data.frame] | [Task])\cr
#'   Input data.
#' @md
