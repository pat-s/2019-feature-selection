library(testthat)
library(hunspell)

test_check("hunspell")
