library(testthat)
library(rrtools)

test_check("rrtools")
