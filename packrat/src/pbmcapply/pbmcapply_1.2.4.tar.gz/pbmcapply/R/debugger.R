# Load packages
library(parallel)
library(future)
library(utils)

# Load R scripts
source("R/progressBar.R")
source("R/txtProgressBarETA.R")
source("R/utils.R")
