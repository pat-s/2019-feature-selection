
context("prompt")

test_that("prompt works", {

  expect_true(TRUE)

})
