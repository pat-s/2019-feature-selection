The examples have moved to https://github.com/wlandau/drake-examples.
