nohup R CMD BATCH all.R &
