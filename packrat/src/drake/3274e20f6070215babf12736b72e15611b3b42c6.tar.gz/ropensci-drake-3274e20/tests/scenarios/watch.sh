watch -n .1 tail -n 30 $1
