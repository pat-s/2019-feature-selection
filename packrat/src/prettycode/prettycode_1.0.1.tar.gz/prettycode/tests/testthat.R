library(testthat)
library(prettycode)

test_check("prettycode")
