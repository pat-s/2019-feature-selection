
# 1.0.1

* Avoid registering the `print.function` S3 method. This is needed to
  avoid a new `R CMD check` check

# 1.0.0

First public release.
