if (!interactive())
{
  suppressMessages(getPass:::readline_nomask("asdf", noblank=FALSE))
}
