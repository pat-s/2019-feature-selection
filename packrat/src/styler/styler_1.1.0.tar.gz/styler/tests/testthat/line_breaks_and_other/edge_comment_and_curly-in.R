a <- function(x) # this is a comment and the bracket below should not be moved one line up after the comment.
{
  x
}
