call(
  a,
  b, c
)

call(
  a,
  b,
  c
)

call(a, )
call(a, )

call(
  a,
)
