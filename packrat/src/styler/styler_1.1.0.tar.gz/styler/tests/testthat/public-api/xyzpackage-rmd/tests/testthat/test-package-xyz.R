context("testing styler on package")

test_that("hi there", {
  I(am(a(package(x))))
})
