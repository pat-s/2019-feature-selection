strsplit("\n", fixed = TRUE) %>%
  .[[1L]]
