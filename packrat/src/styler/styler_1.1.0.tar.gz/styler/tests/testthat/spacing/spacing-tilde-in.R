a~b
~b
~b+ c
a + b ~c

a  ~b
 ~b
~  b+c
a + b~  c
