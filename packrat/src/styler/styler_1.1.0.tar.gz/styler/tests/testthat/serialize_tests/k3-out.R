#k3
call(1,
call2(call(3,            1, 2),
  4))
