if (X)
  return(TRUE)

if (X) return(FALSE)
