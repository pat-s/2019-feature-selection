x <- 5

if (x >= 5) {
  y <- TRUE
} else {
  y <- FALSE
}
