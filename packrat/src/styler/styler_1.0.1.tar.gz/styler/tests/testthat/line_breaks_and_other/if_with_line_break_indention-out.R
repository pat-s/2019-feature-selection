# adding line-break
if (x) {
  1 + 1 + +1
} else {
  3
}

# removing line-break
test_that("x", {
  my_test(call)
})
