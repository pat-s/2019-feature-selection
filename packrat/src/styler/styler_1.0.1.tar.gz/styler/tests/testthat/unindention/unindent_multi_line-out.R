call(
  engine,
  xetex = {
    x
  },
  luatex = {
    x
  }, {
    xx
}) # FIXME: line break after '}', see also #125
