{
  (((
    2
  )))
}

{
  {
    call(
      call1(2, 3), {
        sin(cos(pi))
      }
    )
  }
}
