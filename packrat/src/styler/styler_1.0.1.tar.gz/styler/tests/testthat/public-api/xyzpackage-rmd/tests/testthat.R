library(testthat)
library(xyzpackage)

test_check("xyzpackage")
