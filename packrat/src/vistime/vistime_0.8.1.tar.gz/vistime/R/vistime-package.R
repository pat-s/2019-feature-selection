#' Visualize interactive timelines offline.
#'
#' @name vistime
#' @docType package
#' @title Create a Timeline
#' @author Sandro Raabe \email{shosaco_nospam@hotmail.com}
#' @keywords timeline plotly gantt vistime
NULL
