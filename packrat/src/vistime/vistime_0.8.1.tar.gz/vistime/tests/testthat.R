library(testthat)
# library(vistime)

# devtools::test()

test_check("vistime")
