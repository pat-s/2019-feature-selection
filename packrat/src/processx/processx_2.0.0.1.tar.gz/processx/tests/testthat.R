library(testthat)
library(processx)

test_check("processx")
