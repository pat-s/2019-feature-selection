beeswarm
========

An R package implementing bee swarm plots


You can see some examples here:
http://www.cbs.dtu.dk/~eklund/beeswarm/


Installation
------------

You can install the latest release on CRAN like this:

	install.packages("beeswarm")


You can install the latest development version from GitHub like this:

	library(devtools)
	install_github("aroneklund/beeswarm")
