library(testthat)
test_check("mlrCPO", filter = "^_lint")

