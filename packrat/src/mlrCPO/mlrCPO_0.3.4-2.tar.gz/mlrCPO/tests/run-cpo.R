library(testthat)
ISTESTING = TRUE  # nolint
test_check("mlrCPO", filter = "^_cpo_")

