library(testthat)
library(ModelMetrics)

test_check("ModelMetrics")
