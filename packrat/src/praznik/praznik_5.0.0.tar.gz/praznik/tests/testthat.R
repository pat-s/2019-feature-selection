library(testthat)
library(praznik)

test_check("praznik")
